Space Shooter – Pygame Project

Created by: Adhithyan Panangadan Shaju
Immatriculation Number: 100004210
Program: B.Sc. Computer Science
University: SRH Berlin University of Applied Sciences
Date of Submission: 21st July 2025

About the Game

Space Shooter is a 2-player arcade-style game developed using Python and the Pygame library. Two players control spaceships (Red and Yellow) and try to defeat each other by firing bullets. Each spaceship starts with 10 health points.

For every 3 hits a player takes, they gain a temporary shield that blocks one incoming bullet. The goal is to reduce your opponent’s health to 0. Once a player wins, the game restarts automatically for another round.

Main Features

Two-player battle (Red vs Yellow)

Health and auto-shield system

Firing bullets with sound effects

Game restarts after each win

Menu with help/instructions panel

OOP-based structure with reusable classes

Controls

🟡 Yellow Player
Move: W / A / S / D
Shoot: Left Ctrl

🔴 Red Player
Move: Arrow Keys
Shoot: Right Ctrl

🕹 Menu Navigation

ENTER – Start Game

H – Help screen

B – Back to Main Menu

How to Run

Make sure Python 3 is installed

Install Pygame using: pip install pygame
Ensure all files are in one folder:

[main.py

README.txt

Assets/ folder], Assets/ folder which includes

(spaceship_yellow.png

spaceship_red.png

space.png

Gun+Silencer.mp3

Grenade+1.mp3)

Run the game using your terminal:python main.py
Classes Used

Spaceship – Handles movement, firing, health, shields

BulletManager – Manages all bullet collisions and logic

GameManager – Manages drawing, health checks, winner display, and game loop

Submission Instructions

Zip the folder containing:

main.py

README.txt

Assets/ folder with all images and sound files

Email the zip file to:
navaneethsrhteacher@gmail.com

Use the following subject line:
Pygame Project Submission – Adhithyan Panangadan Shaju – 100004210

Submit by the deadline: 22nd July 2025

Thank You!

Thank you for reviewing my project. I had a great time building this and applying what I’ve learned about object-oriented programming and Pygame development during the course. I look forward to your feedback!
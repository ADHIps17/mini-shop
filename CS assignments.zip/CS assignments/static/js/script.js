console.log("Static JS is working!");

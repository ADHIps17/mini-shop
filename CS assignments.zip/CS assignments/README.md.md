\# Mini Shop Django Project



A simple e-commerce Django application with user accounts, product management, shopping cart, orders, and an admin dashboard.



---



\## Features



\- User authentication (signup, login, logout)

\- Product catalog with details and search

\- Shopping cart (add/remove items)

\- Checkout and order management

\- Dashboard showing order and cart statistics

\- Admin panel to manage products, orders, and users



---



\## Requirements



\- Python 3.10+

\- Django 4.x

\- SQLite (default DB)

\- Other Python packages listed in `requirements.txt`



---



\## Installation



1\. \*\*Clone the repository\*\*



```bash

git clone <your-repo-url>

cd mini\_shop





##### Create a virtual environment

python -m venv venv

\# Linux/macOS

source venv/bin/activate

\# Windows

venv\\Scripts\\activate







##### Install dependencies

pip install -r requirements.txt





##### Apply migrations

python manage.py makemigrations

python manage.py migrate





##### create a superuser for admin access

python manage.py createsuperuser





##### Run the development server

python manage.py runserver





##### open the link and check the usage

**1.Sign up and log in as a user.**



**2.Browse products on the homepage.**



**3.Add products to your cart.**



**4.Checkout to place an order.**



**5.View current orders and order history.**



**6.Admin users can manage products, orders, and users from the Django admin panel.**




from django.urls import path
# Import the 'path' function to define URL patterns

from .views import product_list, product_add, product_edit, product_delete, product_detail, search_products
# Import all the view functions from the products app

app_name = 'products'
# Namespace for this app's URLs; used to uniquely reference URLs in templates
# Example: {% url 'products:product_list' %}

urlpatterns = [
    path('', product_list, name='product_list'),
    # Root URL of products app ('/products/') → shows list of products

    path('add/', product_add, name='product_add'),
    # URL for adding a new product ('/products/add/') → admin only

    path('edit/<int:pk>/', product_edit, name='product_edit'),
    # URL to edit a product by primary key ('/products/edit/1/') → admin only

    path('delete/<int:pk>/', product_delete, name='product_delete'),
    # URL to delete a product by primary key ('/products/delete/1/') → admin only

    path('<int:pk>/', product_detail, name='product_detail'),
    # URL to view product details by primary key ('/products/1/')

    path('search/', search_products, name='search_products'),
    # URL for searching products ('/products/search/') → accessible to everyone
]

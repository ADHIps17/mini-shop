from django import forms
# Import Django's form framework

from .models import Product
# Import the Product model from the same app

class ProductForm(forms.ModelForm):
    # Define a form for creating/editing Product instances using a ModelForm
    # ModelForm automatically generates form fields based on the model

    class Meta:
        model = Product
        # Specifies that this form is tied to the Product model

        fields = ['code', 'name', 'description', 'price', 'stock']
        # List of fields to include in the form
        # Django will automatically create form fields corresponding to these model fields

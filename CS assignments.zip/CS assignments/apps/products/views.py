from django.contrib.admin.views.decorators import staff_member_required
# Decorator to restrict certain views to staff/admin users only

from django.shortcuts import render, redirect, get_object_or_404
# Utilities to render templates, redirect users, and safely get objects or raise 404 if not found

from .models import Product
# Import the Product model from this app

from .forms import ProductForm
# Import the ProductForm form class for adding/editing products

# List all products (everyone can see)
def product_list(request):
    products = Product.objects.all()
    # Retrieve all products from the database
    return render(request, 'products/list.html', {'products': products})
    # Render the 'list.html' template, passing all products as context

# Product details (everyone can see)
def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    # Get a product by primary key or return 404 if not found
    return render(request, 'products/details.html', {'product': product})
    # Render the 'details.html' template for this product

# Add a new product (admin only)
@staff_member_required
def product_add(request):
    if request.method == 'POST':
        # Form was submitted
        form = ProductForm(request.POST)
        # Bind form data
        if form.is_valid():
            form.save()
            # Save the new product to the database
            return redirect('products:product_list')
            # Redirect back to product list after saving
    else:
        form = ProductForm()
        # Show empty form if GET request
    return render(request, 'products/form.html', {'form': form})
    # Render the form template

# Edit a product (admin only)
@staff_member_required
def product_edit(request, pk):
    product = get_object_or_404(Product, pk=pk)
    # Get the product to edit
    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        # Bind form data to existing product
        if form.is_valid():
            form.save()
            # Save changes
            return redirect('products:product_list')
    else:
        form = ProductForm(instance=product)
        # Pre-fill form with existing product data
    return render(request, 'products/form.html', {'form': form})
    # Render the form template

# Delete a product (admin only)
@staff_member_required
def product_delete(request, pk):
    product = get_object_or_404(Product, pk=pk)
    # Get the product to delete
    if request.method == 'POST':
        product.delete()
        # Delete product from database
        return redirect('products:product_list')
    return render(request, 'products/delete.html', {'product': product})
    # Render a confirmation page before deleting

# Search products (everyone can use)
def search_products(request):
    query = request.GET.get('q', '').strip()
    # Get the search query from the GET parameter 'q' and remove extra spaces

    if query:
        # If query is not empty
        results = Product.objects.filter(name__icontains=query) | Product.objects.filter(code__icontains=query)
        # Search products where name or code contains the query (case-insensitive)
    else:
        results = Product.objects.all()
        # Empty search returns all products

    return render(request, 'products/search_results.html', {'query': query, 'results': results})
    # Render the search results template with the query and matching products

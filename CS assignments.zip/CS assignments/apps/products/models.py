from django.db import models
# Import Django's model classes to define database tables

class Product(models.Model):
    # Defines the Product model/table in the database

    name = models.CharField(max_length=255)
    # Product name: a string field with a max length of 255 characters

    code = models.CharField(max_length=10, unique=True, blank=True, null=True)
    # Optional product code: max 10 characters, must be unique if provided
    # blank=True → allows empty in forms
    # null=True → allows NULL in the database

    description = models.TextField(blank=True)
    # Optional description field with no character limit

    price = models.DecimalField(max_digits=10, decimal_places=2)
    # Product price: up to 10 digits total, with 2 decimal places (e.g., 99999999.99)

    stock = models.PositiveIntegerField(default=0)
    # Number of items in stock: must be 0 or positive, default is 0

    def __str__(self):
        # Defines how the object is displayed in admin or shell
        return f"{self.code + ' - ' if self.code else ''}{self.name}"
        # Shows "code - name" if code exists, otherwise just the name

from django.apps import AppConfig
# Import Django's AppConfig class to configure application settings

class ProductsConfig(AppConfig):
    # Defines configuration for the products app

    default_auto_field = 'django.db.models.BigAutoField'
    # Sets the default type for auto-generated primary keys in models
    # BigAutoField is a large integer that avoids collisions in big databases

    name = 'apps.products'
    # Specifies the full Python path to this app
    # This is how Django identifies and registers the app in INSTALLED_APPS

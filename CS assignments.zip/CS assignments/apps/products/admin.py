from django.contrib import admin
# Import Django's admin module to register models for the admin interface

from .models import Product
# Import the Product model from this app

admin.site.register(Product)
# Register the Product model with the Django admin site
# This allows you to add, edit, and delete products from the admin interface

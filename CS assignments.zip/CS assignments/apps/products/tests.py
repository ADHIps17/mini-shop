from django.test import TestCase
# Import Django's TestCase class for writing automated tests.
# TestCase provides utilities to test models, views, and templates in isolation.

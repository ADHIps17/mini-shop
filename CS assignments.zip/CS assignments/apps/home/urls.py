from django.urls import path
# Import Django's path function to define URL patterns

from . import views
# Import views from the current app (home)

app_name = 'home'
# Namespace for this app's URLs to allow safe reverse URL lookups
# Example usage in templates: {% url 'home:index' %}

urlpatterns = [
    path('', views.index, name='index'),
    # Root URL ('/') → calls the index view to render the home page
]

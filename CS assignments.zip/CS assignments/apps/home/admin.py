from django.contrib import admin
# Import Django's admin module

# No models to register for purely static homepage
# This app only renders templates (like home/index.html) and does not have database models

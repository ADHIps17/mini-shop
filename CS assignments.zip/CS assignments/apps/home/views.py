from django.shortcuts import render
# Import render to return HTML responses with context

from apps.products.models import Product
# Import the Product model to fetch products for display

def index(request):
    """
    Home page view that displays all products.
    """
    # Retrieve all products from the database
    products = Product.objects.all()

    # Prepare context dictionary to pass to the template
    context = {
        'products': products
    }

    # Render 'home/index.html' template with products
    return render(request, 'home/index.html', context)

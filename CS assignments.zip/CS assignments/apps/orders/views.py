from django.shortcuts import render, redirect, get_object_or_404
# Utilities to render templates, redirect users, and safely get objects or raise 404

from django.contrib.auth.decorators import login_required
# Decorator to restrict views to logged-in users

from .models import Order
# Import the Order model from this app

from apps.products.models import Product
# Import the Product model from the products app (needed for stock updates)

@login_required
def orders_list(request):
    """Show all active orders for the logged-in user"""
    orders = Order.objects.filter(user=request.user, status="active").order_by('-created_at')
    # Fetch active orders for the current user, newest first

    orders_data = []
    for order in orders:
        items = order.items.all()  # uses related_name="items"
        # Get all items in this order
        orders_data.append({
            'order': order,
            'items': items,
        })
        # Prepare data for the template

    return render(request, 'orders/orders.html', {'orders': orders_data})
    # Render the orders template with the list of active orders

@login_required
def order_history(request):
    """Show cancelled orders (order history)"""
    orders = Order.objects.filter(user=request.user, status="cancelled").order_by('-created_at')
    # Fetch cancelled orders for the current user

    orders_data = []
    for order in orders:
        items = order.items.all()
        orders_data.append({
            'order': order,
            'items': items,
        })

    return render(request, 'orders/history.html', {'orders': orders_data})
    # Render the history template with cancelled orders

@login_required
def cancel_order(request, order_id):
    """Cancel an active order and restore product stock"""
    order = get_object_or_404(Order, id=order_id, user=request.user, status="active")
    # Ensure the order exists, belongs to the user, and is active

    if request.method == 'POST':
        # Restore stock for each order item
        for item in order.items.all():
            try:
                product = item.product  # If OrderItem has FK to Product
                product.stock += item.quantity
                product.save()
            except AttributeError:
                # If only product_name is stored instead of FK
                try:
                    product = Product.objects.get(name=item.product_name)
                    product.stock += item.quantity
                    product.save()
                except Product.DoesNotExist:
                    continue
        # Cancel the order
        order.status = "cancelled"
        order.save()
        return redirect('orders:orders_list')
        # Redirect to active orders list

    return render(request, 'orders/cancel_order.html', {'order': order})
    # Render a confirmation page if GET request

@login_required
def delete_order(request, order_id):
    """Delete a cancelled order from history"""
    order = get_object_or_404(Order, id=order_id, user=request.user, status="cancelled")
    # Ensure the order exists, belongs to the user, and is cancelled

    if request.method == 'POST':
        order.delete()
        # Delete the order from database
        return redirect('orders:order_history')
        # Redirect to order history

    return render(request, 'orders/delete_order.html', {'order': order})
    # Render a confirmation page if GET request

from django.apps import AppConfig
# Import Django's AppConfig to configure application settings

class OrdersConfig(AppConfig):
    # Defines configuration for the orders app

    default_auto_field = 'django.db.models.BigAutoField'
    # Sets the default primary key type for models in this app
    # BigAutoField is a large integer to avoid ID collisions

    name = 'apps.orders'
    # Python path to the orders app
    # Used by Django to register the app in INSTALLED_APPS

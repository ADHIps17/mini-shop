from django.urls import path
# Import Django's path function to define URL patterns

from .views import orders_list, cancel_order, order_history, delete_order
# Import the view functions from the orders app

app_name = 'orders'
# Namespace for this app’s URLs, used in templates and reverse URL lookups
# Example: {% url 'orders:orders_list' %}

urlpatterns = [
    path('', orders_list, name='orders_list'),
    # Root URL of orders app ('/orders/') → shows active orders

    path('history/', order_history, name='order_history'),
    # URL for viewing cancelled orders ('/orders/history/')

    path('cancel/<int:order_id>/', cancel_order, name='cancel_order'),
    # URL to cancel a specific active order by ID ('/orders/cancel/1/')

    path('delete/<int:order_id>/', delete_order, name='delete_order'),
    # URL to delete a specific cancelled order by ID ('/orders/delete/1/')
]

from django.contrib import admin
# Import Django admin module

from .models import Order, OrderItem
# Import Order and OrderItem models from this app

from apps.products.models import Product
# Import Product model to get product details for display

# Inline display for OrderItems in the Order admin
class OrderItemInline(admin.TabularInline):
    model = OrderItem
    # This inline displays OrderItem rows within the Order admin page

    readonly_fields = ('product_name', 'quantity', 'product_code', 'product_price', 'item_total')
    # Fields that cannot be edited in the admin inline

    extra = 0  # do not show extra empty rows

    def product_code(self, obj):
        try:
            product = Product.objects.get(name=obj.product_name)
            return product.code
        except Product.DoesNotExist:
            return '-'
    product_code.short_description = 'Code'
    # Shows product code if it exists, otherwise '-'

    def product_price(self, obj):
        try:
            product = Product.objects.get(name=obj.product_name)
            return product.price
        except Product.DoesNotExist:
            return 0
    product_price.short_description = 'Price'
    # Shows product price, or 0 if product not found

    def item_total(self, obj):
        return obj.quantity * self.product_price(obj)
    item_total.short_description = 'Total'
    # Calculates total price for this item (quantity × price)

# Customize Order admin
class OrderAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'status', 'created_at', 'total_amount')
    # Columns to show in the admin order list

    list_filter = ('status', 'created_at')
    # Filters for status and creation date

    search_fields = ('user__username', 'id')
    # Search by user username or order ID

    inlines = [OrderItemInline]
    # Show order items inline in the order admin page

    def total_amount(self, obj):
        total = 0
        for item in obj.items.all():
            try:
                product = Product.objects.get(name=item.product_name)
                total += product.price * item.quantity
            except Product.DoesNotExist:
                continue
        return total
    total_amount.short_description = 'Total Amount'
    # Calculate total amount of the order by summing all items

# Register models
admin.site.register(Order, OrderAdmin)
# Register Order model with customized admin

admin.site.register(OrderItem)
# Register OrderItem separately (optional)

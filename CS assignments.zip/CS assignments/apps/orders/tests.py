from django.test import TestCase
# Import Django's TestCase class for writing automated tests

from django.contrib.auth import get_user_model
# Utility to get the currently active user model

from .models import Order, OrderItem
# Import the Order and OrderItem models from this app

User = get_user_model()
# Assign the custom or default User model to `User`

class OrdersTests(TestCase):
    # Test class for Orders and OrderItem functionality

    def setUp(self):
        # Runs before each test to set up test data

        # Create a test user
        self.user = User.objects.create_user(
            username="testuser",
            email="test@example.com",
            password="password123"
        )

        # Create an order for the user
        self.order = Order.objects.create(user=self.user)

        # Add items to the order
        self.item1 = OrderItem.objects.create(
            order=self.order,
            product_name="Product 1",
            quantity=2,
            price=10.00
        )
        self.item2 = OrderItem.objects.create(
            order=self.order,
            product_name="Product 2",
            quantity=1,
            price=20.00
        )

    def test_order_total_amount(self):
        # Test that the total_amount() method calculates correctly
        # (2*10) + (1*20) = 40
        self.assertEqual(self.order.total_amount(), 40.00)

    def test_order_item_str(self):
        # Test the string representation of an OrderItem
        self.assertEqual(str(self.item1), "Product 1 x 2 (Order 1)")

    def test_order_str(self):
        # Test the string representation of an Order
        self.assertEqual(str(self.order), f"Order {self.order.id} by {self.user.username}")

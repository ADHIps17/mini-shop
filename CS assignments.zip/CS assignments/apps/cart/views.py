from django.shortcuts import render, redirect, get_object_or_404
# render → to render templates
# redirect → to send user to another page
# get_object_or_404 → fetch object or return 404 if it doesn't exist

from django.contrib.auth.decorators import login_required
# ensures only logged-in users can access certain views

from django.urls import reverse
# allows reversing view names into URL paths

from apps.products.models import Product
from apps.orders.models import Order, OrderItem
from .models import Cart, CartItem
# import necessary models: Products, Orders, Cart & CartItems


# Helper function: get or create a cart for a user
def get_user_cart(user):
    cart, created = Cart.objects.get_or_create(user=user)
    return cart
# If the user already has a cart, fetch it; otherwise, create a new cart


# ------------------------
# VIEW: Show Cart Details
# ------------------------
@login_required
def cart_detail(request):
    cart = get_user_cart(request.user)
    items = cart.items.all()
    # fetch all items in the user's cart

    items_with_price = []
    total = 0
    for item in items:
        try:
            product = Product.objects.get(name=item.product_name)
            item_total = product.price * item.quantity
            total += item_total
            items_with_price.append({
                'id': item.id,
                'name': product.name,
                'quantity': item.quantity,
                'price': product.price,
                'total': item_total,
            })
        except Product.DoesNotExist:
            continue
    # prepare a detailed list of items with price and total for display

    previous_url = request.META.get('HTTP_REFERER', reverse('home-index'))
    # store previous page URL for a "back" button

    return render(request, 'cart/cart_details.html', {
        'items': items_with_price,
        'total': total,
        'previous_url': previous_url
    })
# renders the cart page with items, total price, and previous URL


# ------------------------
# VIEW: Add Product to Cart
# ------------------------
@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    # fetch product by ID or return 404 if not found

    if request.user.is_staff:
        return redirect('products:product_list')
    # staff users cannot add products to cart

    cart = get_user_cart(request.user)
    item, created = CartItem.objects.get_or_create(cart=cart, product_name=product.name)
    if not created:
        item.quantity += 1
        item.save()
    # if item exists in cart, increase quantity; otherwise create new CartItem

    next_url = request.GET.get('next') or request.META.get('HTTP_REFERER') or reverse('home-index')
    return redirect(next_url)
# redirects user back to previous page or home after adding product


# ------------------------
# VIEW: Remove Item from Cart
# ------------------------
@login_required
def remove_from_cart(request, item_id):
    cart = get_user_cart(request.user)
    item = get_object_or_404(CartItem, id=item_id, cart=cart)
    item.delete()
    # delete the selected item from the cart

    next_url = request.POST.get('next') or request.META.get('HTTP_REFERER') or reverse('cart:cart_detail')
    return redirect(next_url)
# redirects user back to previous page or cart details after deletion


# ------------------------
# VIEW: Checkout & Create Order
# ------------------------
@login_required
def checkout(request):
    cart = get_user_cart(request.user)
    items = cart.items.all()
    # get all items in the user's cart

    items_with_price = []
    total = 0
    for item in items:
        try:
            product = Product.objects.get(name=item.product_name)
            item_total = product.price * item.quantity
            total += item_total
            items_with_price.append({
                'id': item.id,
                'name': product.name,
                'quantity': item.quantity,
                'price': product.price,
                'total': item_total,
            })
        except Product.DoesNotExist:
            continue
    # prepare list of items with prices for checkout page

    previous_url = request.META.get('HTTP_REFERER', reverse('home-index'))
    # save previous page URL for redirect or back button

    if request.method == 'POST':
        address = request.POST.get('address')
        city = request.POST.get('city')
        postal_code = request.POST.get('postal_code')
        # collect shipping information from checkout form

        # create a new order
        order = Order.objects.create(
            user=request.user,
            address=address,
            city=city,
            postal_code=postal_code,
            status='active'
        )

        # add each cart item to the order and reduce product stock
        for item in items:
            try:
                product = Product.objects.get(name=item.product_name)
                if product.stock >= item.quantity:
                    product.stock -= item.quantity
                    product.save()
                    OrderItem.objects.create(
                        order=order,
                        product_name=item.product_name,
                        quantity=item.quantity
                    )
            except Product.DoesNotExist:
                continue
        # if product doesn't exist, skip it

        cart.items.all().delete()
        # clear the cart after checkout

        return redirect('orders:orders_list')
    # redirect user to their orders page after successful checkout

    return render(request, 'cart/checkout.html', {
        'items': items_with_price,
        'total': total,
        'previous_url': previous_url
    })
# render checkout page for GET requests

from django.test import TestCase
from django.contrib.auth import get_user_model  # get the user model (custom or default)
from apps.products.models import Product  # import Product model for cart items
from .models import Cart, CartItem  # import Cart and CartItem models

User = get_user_model()  # get the active user model

class CartTests(TestCase):
    """
    Test suite for Cart and CartItem functionality.
    """

    def setUp(self):
        """
        Set up a test user, a product, and a cart for testing.
        This runs before each test method.
        """
        # Create a test user
        self.user = User.objects.create_user(
            username="testuser",
            email="test@example.com",
            password="password123"
        )

        # Create a test product
        self.product = Product.objects.create(
            name="Test Product",
            price=50.0
        )

        # Create a cart for the test user
        self.cart = Cart.objects.create(user=self.user)

    def test_cart_creation(self):
        """
        Ensure the cart is correctly linked to the user.
        """
        self.assertEqual(self.cart.user.username, "testuser")
        self.assertTrue(self.cart.is_active)  # check cart is marked active (if field exists)

    def test_add_cart_item(self):
        """
        Test adding an item to the cart increases quantity and calculates total price correctly.
        """
        item = CartItem.objects.create(cart=self.cart, product=self.product, quantity=2)
        self.assertEqual(item.quantity, 2)
        self.assertEqual(item.get_total_price(), 100.0)  # 2 * 50.0

    def test_cart_items_relationship(self):
        """
        Verify multiple items can be added to a cart and counted correctly.
        """
        CartItem.objects.create(cart=self.cart, product=self.product, quantity=1)
        CartItem.objects.create(cart=self.cart, product=self.product, quantity=3)
        self.assertEqual(self.cart.items.count(), 2)  # there should be 2 CartItem objects

    def test_cart_item_str(self):
        """
        Ensure the string representation of a CartItem is human-readable.
        """
        item = CartItem.objects.create(cart=self.cart, product=self.product, quantity=1)
        expected_str = f"1 x {self.product.name} in {self.user.username}'s cart"
        self.assertEqual(str(item), expected_str)

from django.contrib import admin
from .models import Cart, CartItem

# Inline admin configuration to show CartItems inside a Cart
class CartItemInline(admin.TabularInline):
    """
    Allows CartItems to be displayed and edited inline within the Cart admin page.
    
    Attributes:
    - model: specifies the model for the inline (CartItem).
    - extra: number of extra empty forms to display (0 disables extra empty rows).
    """
    model = CartItem
    extra = 0  # don't show empty extra rows

# Admin configuration for the Cart model
class CartAdmin(admin.ModelAdmin):
    """
    Customizes the admin interface for Cart.

    Attributes:
    - list_display: fields to show in the Cart list view (user and creation date).
    - inlines: allows CartItems to be edited inline within a Cart.
    """
    list_display = ('user', 'created_at')  # show user and creation date
    inlines = [CartItemInline]  # include CartItems inline

# Register models with the admin site
admin.site.register(Cart, CartAdmin)  # register Cart with custom admin
admin.site.register(CartItem)          # register CartItem separately if needed

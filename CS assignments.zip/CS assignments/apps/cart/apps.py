from django.apps import AppConfig

class CartConfig(AppConfig):
    """
    Configuration class for the 'cart' app.

    Attributes:
    - default_auto_field: sets the default type for primary keys to BigAutoField.
    - name: full Python path to the app module ('apps.cart').
    
    This class is used by Django to register the app and its configuration.
    """
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.cart'

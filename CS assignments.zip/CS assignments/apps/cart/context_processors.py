from .models import Cart

def cart_context(request):
    """
    Provides cart-related context globally to all templates.

    - `cart_items_count`: total number of items in the user's cart
    - `cart_items`: queryset of CartItem objects in the cart
    """
    cart_items_count = 0
    cart_items = []

    if request.user.is_authenticated:
        try:
            # Access the cart using the related_name defined in Cart model
            cart = request.user.user_cart
            cart_items = cart.items.all()
            cart_items_count = cart_items.count()
        except Cart.DoesNotExist:
            # User has no cart yet
            pass

    return {
        'cart_items_count': cart_items_count,
        'cart_items': cart_items
    }

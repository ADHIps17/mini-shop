from django.db import models
from django.conf import settings  # for referencing the user model (AUTH_USER_MODEL)

class Cart(models.Model):
    """
    Represents a shopping cart for a single user.
    Each user has exactly one cart (OneToOneField).
    """
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='user_cart'  # allows reverse access: user.user_cart
    )
    created_at = models.DateTimeField(auto_now_add=True)  # record creation timestamp

    def __str__(self):
        """
        Human-readable representation of the cart.
        """
        return f"{self.user.username}'s Cart"


class CartItem(models.Model):
    """
    Represents a single item in a Cart.
    """
    cart = models.ForeignKey(
        Cart,
        on_delete=models.CASCADE,
        related_name='items'  # reverse access: cart.items.all()
    )
    product_name = models.CharField(max_length=255)  # store product name (denormalized)
    quantity = models.PositiveIntegerField(default=1)  # number of units of the product

    def __str__(self):
        """
        Human-readable representation of the CartItem.
        """
        return f"{self.product_name} x {self.quantity}"

    def get_total_price(self):
        """
        Calculate total price of this item.
        Looks up the product by name and multiplies by quantity.
        """
        from apps.products.models import Product
        product = Product.objects.get(name=self.product_name)
        return self.quantity * product.price

from django.urls import path
from . import views  # import all views from the cart app

app_name = 'cart'  # namespace for reverse URL lookups

urlpatterns = [
    # Display the current user's cart
    path('', views.cart_detail, name='cart_detail'),

    # Add a product to the user's cart by product ID
    path('add/<int:product_id>/', views.add_to_cart, name='add_to_cart'),

    # Remove a specific item from the cart by item ID
    path('remove/<int:item_id>/', views.remove_from_cart, name='remove_from_cart'),

    # Checkout page to finalize cart into an order
    path('checkout/', views.checkout, name='checkout'),
]

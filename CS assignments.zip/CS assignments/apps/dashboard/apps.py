from django.apps import AppConfig
# Import Django's AppConfig to configure the application

class DashboardConfig(AppConfig):
    # Defines configuration for the dashboard app

    default_auto_field = 'django.db.models.BigAutoField'
    # Sets the default primary key type for models in this app

    name = 'apps.dashboard'
    # Python path to the dashboard app
    # Used by Django to register the app in INSTALLED_APPS

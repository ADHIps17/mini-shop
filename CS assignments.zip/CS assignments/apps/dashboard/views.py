from django.shortcuts import render
# Import render to return HTML responses with context

from django.contrib.auth.decorators import login_required
# Decorator to ensure only logged-in users can access the dashboard

from apps.orders.models import Order, OrderItem
# Import Order and OrderItem models to fetch user orders

from apps.cart.models import Cart, CartItem
# Import Cart and CartItem models to fetch cart data

@login_required
def dashboard_home(request):
    # Dashboard homepage view

    # Fetch all orders for the logged-in user, ordered by newest first
    orders = Order.objects.filter(user=request.user).order_by('-created_at')

    # Count active orders
    active_orders_count = orders.filter(status='active').count()

    # Count cancelled orders
    cancelled_orders_count = orders.filter(status='cancelled').count()

    # Count cart items
    cart_items_count = 0
    try:
        cart = Cart.objects.get(user=request.user)
        cart_items_count = cart.items.count()
    except Cart.DoesNotExist:
        cart_items_count = 0
    # If user has no cart, count remains 0

    # Pass all data to the template
    context = {
        'orders': orders,
        'active_orders_count': active_orders_count,
        'cancelled_orders_count': cancelled_orders_count,
        'cart_items_count': cart_items_count,
    }

    return render(request, 'dashboard/dashboard.html', context)
    # Render dashboard template with context

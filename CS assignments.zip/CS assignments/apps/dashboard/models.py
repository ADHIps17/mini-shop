from django.db import models
# Import Django's models module to define database models

from django.conf import settings
# Import settings to reference the custom user model

class Cart(models.Model):
    # Model to represent a shopping cart for a user

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='dashboard_cart'  # avoids clashes with other user relationships
    )
    # Each cart belongs to one user. If the user is deleted, their cart is deleted.

    created_at = models.DateTimeField(auto_now_add=True)
    # Timestamp when the cart was created

    updated_at = models.DateTimeField(auto_now=True)
    # Timestamp updated automatically whenever the cart changes

    def __str__(self):
        return f"Dashboard Cart of {self.user.username}"
    # Human-readable representation of the cart

from django.urls import path
# Import Django's path function to define URL patterns

from .views import dashboard_home
# Import the dashboard_home view from this app

app_name = 'dashboard'
# Namespace for this app's URLs, allowing reverse URL lookups like {% url 'dashboard:dashboard_home' %}

urlpatterns = [
    path('', dashboard_home, name='dashboard_home'),
    # Root URL of the dashboard app → calls dashboard_home view
]

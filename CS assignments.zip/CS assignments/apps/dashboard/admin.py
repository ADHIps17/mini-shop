from apps.cart.models import Cart, CartItem
# Import the Cart and CartItem models from the cart app
# These models are used to manage the shopping cart system:
# - Cart: Represents a user's shopping cart
# - CartItem: Represents individual products/items inside a Cart

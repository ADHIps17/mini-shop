from django.test import TestCase
# Import Django's TestCase for unit testing

from django.urls import reverse
# Import reverse to get URLs by their name instead of hardcoding

class DashboardViewTests(TestCase):
    # Test class for the dashboard view

    def test_dashboard_view_status_code(self):
        # Test if the dashboard page loads successfully
        response = self.client.get(reverse('dashboard'))
        # Make a GET request to the dashboard URL using reverse lookup
        self.assertEqual(response.status_code, 200)
        # Assert that the response has status code 200 (OK)

    def test_dashboard_view_template(self):
        # Test if the correct template is used for the dashboard
        response = self.client.get(reverse('dashboard'))
        self.assertTemplateUsed(response, 'dashboard/dashboard.html')
        # Assert that 'dashboard/dashboard.html' is used for rendering

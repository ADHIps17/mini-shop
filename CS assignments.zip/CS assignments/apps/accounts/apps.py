from django.apps import AppConfig  # ✅ Required to configure the app in Django

class AccountsConfig(AppConfig):
    """
    Configuration for the 'accounts' app.

    Key Points:
    1. default_auto_field: Ensures new models use BigAutoField by default for primary keys.
    2. name: Specifies the full Python path to this app ('apps.accounts'), allowing Django to locate it.
    3. This class is automatically referenced in INSTALLED_APPS to initialize the app correctly.

    Usage: Django reads this config when the app is loaded.
    """
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.accounts'

# apps/accounts/forms.py

from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser

class CustomUserCreationForm(UserCreationForm):
    """
    Form to handle registration of a new CustomUser.

    Key Features:
    1. Inherits from Django's built-in UserCreationForm for password validation and user creation.
    2. Uses the CustomUser model, ensuring compatibility with the project's custom user system.
    3. Exposes only 'username' and 'email' fields for user signup.
    4. Automatically handles password hashing and validation.
    5. Can be extended to include additional fields like first_name, last_name, or profile info.

    Usage: Used in signup view to register new users.
    """
    class Meta:
        model = CustomUser
        fields = ('username', 'email')  # specify which fields appear on the signup form

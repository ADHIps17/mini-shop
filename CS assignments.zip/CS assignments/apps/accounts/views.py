from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from .forms import CustomUserCreationForm

# -------------------------------
# Signup view
# -------------------------------
def signup_view(request):
    """
    Allows a new user to create an account.
    If the form is submitted (POST), it validates and creates the user,
    then automatically logs them in and redirects to the homepage.
    If it's a GET request, it just displays the signup form.
    """
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)  # bind form to POST data
        if form.is_valid():  # check all fields are valid
            user = form.save()  # save new user to database
            login(request, user)  # automatically log the user in
            return redirect('home:index')  # go to homepage
    else:
        form = CustomUserCreationForm()  # show empty signup form
    return render(request, 'accounts/signup.html', {'form': form})


# -------------------------------
# Login view
# -------------------------------
def login_view(request):
    """
    Allows existing users to log in.
    POST request: authenticate user, log them in, and redirect based on role:
        - Superuser → Django admin
        - Normal user → homepage
    GET request: just display login form.
    """
    error = None
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        if username and password:
            user = authenticate(request, username=username, password=password)  # check credentials
            if user:
                login(request, user)  # log in
                if user.is_superuser:
                    return redirect('/admin/')  # superuser goes to admin dashboard
                return redirect('home:index')  # normal user goes to homepage
            else:
                error = 'Invalid username or password.'
        else:
            error = 'Please enter both username and password.'

    # Render login page with any error messages
    return render(request, 'accounts/login.html', {'error': error})


# -------------------------------
# Logout view
# -------------------------------
def logout_view(request):
    """
    Logs out the current user and redirects to the homepage.
    """
    logout(request)
    return redirect('home:index')

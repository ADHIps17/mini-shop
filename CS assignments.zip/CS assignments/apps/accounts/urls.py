from django.urls import path
from .views import login_view, signup_view, logout_view

# -------------------------------
# App namespace
# -------------------------------
app_name = 'accounts'  # ✅ Allows us to use {% url 'accounts:login' %}, etc.

# -------------------------------
# URL patterns
# -------------------------------
urlpatterns = [
    # Login page
    path('login/', login_view, name='login'),  # Users can log in here

    # Signup page
    path('signup/', signup_view, name='signup'),  # New users can create accounts here

    # Logout action
    path('logout/', logout_view, name='logout'),  # Logs out the current user
]

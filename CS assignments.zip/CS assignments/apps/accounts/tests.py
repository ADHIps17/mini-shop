from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model

# Get the user model (supports custom user model if used)
User = get_user_model()

class AccountsTests(TestCase):

    def setUp(self):
        """
        Create a test user that we can use for login and authentication tests.
        """
        self.user = User.objects.create_user(
            username="testuser",
            email="test@example.com",
            password="password123"
        )

    # -------------------------------
    # Test Signup Page
    # -------------------------------
    def test_signup_page_status_code(self):
        """
        Ensure the signup page loads successfully.
        """
        response = self.client.get(reverse("accounts:signup"))
        self.assertEqual(response.status_code, 200)

    # -------------------------------
    # Test Login Page
    # -------------------------------
    def test_login_page_status_code(self):
        """
        Ensure the login page loads successfully.
        """
        response = self.client.get(reverse("accounts:login"))
        self.assertEqual(response.status_code, 200)

    # -------------------------------
    # Test User Login
    # -------------------------------
    def test_user_login(self):
        """
        Test that the created user can log in successfully.
        """
        login = self.client.login(username="testuser", password="password123")
        self.assertTrue(login)

    # -------------------------------
    # Test Profile Requires Login
    # -------------------------------
    def test_profile_requires_login(self):
        """
        Ensure that accessing a profile page without login redirects to login page.
        """
        response = self.client.get(reverse("profile"))  # assumes a 'profile' URL exists
        self.assertEqual(response.status_code, 302)  # 302 = redirect
        self.assertIn("/login/", response.url)  # redirected to login page

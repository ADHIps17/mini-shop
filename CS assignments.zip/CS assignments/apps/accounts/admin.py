from django.contrib import admin
from .models import CustomUser
from django.contrib.auth.admin import UserAdmin

# Register CustomUser model in Django admin with built-in UserAdmin
# Description:
# 1. This allows you to manage users with the admin interface.
# 2. UserAdmin provides standard fields (username, email, is_staff, etc.) and features (search, filtering, permissions).
# 3. Using CustomUser here ensures your custom fields and relationships are correctly displayed in admin.
admin.site.register(CustomUser, UserAdmin)

from django.contrib.auth.models import AbstractUser, Group, Permission
from django.db import models

class CustomUser(AbstractUser):
    """
    CustomUser extends Django's built-in AbstractUser model to provide a flexible user account system.

    Key Features:
    1. Inherits standard fields like username, email, password, first_name, last_name, etc.
    2. Overrides related_name for groups and user_permissions to avoid conflicts with the default User model:
       - groups: related_name="customuser_set"
       - user_permissions: related_name="customuser_permissions_set"
    3. Supports assigning users to multiple groups and permissions for fine-grained access control.
    4. Extensible for future custom fields such as profile information, preferences, or roles.
    5. Fully compatible with Django authentication, admin, and other apps (orders, cart, dashboard).

    In short: This model serves as the core user model for authentication and user management
    throughout the project while allowing easy customization.
    """
    groups = models.ManyToManyField(
        Group,
        related_name="customuser_set",  # avoids conflict with default User groups
        blank=True
    )
    user_permissions = models.ManyToManyField(
        Permission,
        related_name="customuser_permissions_set",  # avoids conflict with default User permissions
        blank=True
    )

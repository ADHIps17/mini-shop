"""
ASGI config for min_shop project.

It exposes the ASGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/4.2/howto/deployment/asgi/
"""
# Docstring explaining the purpose of this file.
# ASGI (Asynchronous Server Gateway Interface) is the standard interface between asynchronous web servers and Django.

import os
# Provides functions to interact with the operating system (like environment variables)

from django.core.asgi import get_asgi_application
# Imports Django's function to get an ASGI application callable

# Set the default Django settings module
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'min_shop.settings')
# Sets the environment variable 'DJANGO_SETTINGS_MODULE' to your project's settings.
# This tells Django which settings file to use for this ASGI application.

# Get the ASGI application
application = get_asgi_application()
# Creates the ASGI application callable named 'application'.
# ASGI servers (like Daphne or Uvicorn) use this to serve your Django app asynchronously.

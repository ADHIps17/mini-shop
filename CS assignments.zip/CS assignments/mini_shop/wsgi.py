"""
WSGI config for min_shop project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/4.2/howto/deployment/wsgi/
"""
# This is a docstring explaining the purpose of this file.
# WSGI is the interface between your web server and Django.
# This file is used when deploying Django to a production server.

import os
# Imports the os module to interact with environment variables

from django.core.wsgi import get_wsgi_application
# Imports the Django function that returns a WSGI application callable

# Set the default Django settings module
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'min_shop.settings')
# Sets the environment variable 'DJANGO_SETTINGS_MODULE' to point to your project's settings.
# This tells Django which settings to use for this deployment.

# Get the WSGI application
application = get_wsgi_application()
# Creates the WSGI application callable named 'application'.
# Web servers (like Gunicorn or uWSGI) use this callable to serve your Django app.

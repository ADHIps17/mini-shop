import os
# Provides functions to interact with the operating system (paths, environment variables)

from pathlib import Path
# Pathlib allows working with filesystem paths in an easy, object-oriented way

# Base directory
BASE_DIR = Path(__file__).resolve().parent.parent
# Defines the base directory of the project (two levels up from this file)
# Used to build paths relative to the project root

# Security
SECRET_KEY = 'your-secret-key-here'
# Secret key used for cryptographic signing (keep it secret in production!)

DEBUG = True
# Debug mode is ON (shows detailed error pages). Should be False in production.

ALLOWED_HOSTS = []
# List of allowed hostnames/domains for this Django project
# Empty means localhost only (during development)

# Installed apps
INSTALLED_APPS = [
    'django.contrib.admin',          # Admin interface
    'django.contrib.auth',           # Authentication system
    'django.contrib.contenttypes',   # Content type framework (permissions)
    'django.contrib.sessions',       # Session framework
    'django.contrib.messages',       # Messaging framework
    'django.contrib.staticfiles',    # Serving static files

    # Custom apps
    'apps.accounts.apps.AccountsConfig',
    'apps.cart.apps.CartConfig',
    'apps.dashboard.apps.DashboardConfig',
    'apps.home.apps.HomeConfig',
    'apps.orders.apps.OrdersConfig',
    'apps.products.apps.ProductsConfig',
]

# Middleware
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',          # Security headers
    'django.contrib.sessions.middleware.SessionMiddleware',   # Handles sessions
    'django.middleware.common.CommonMiddleware',              # Handles general HTTP stuff
    'django.middleware.csrf.CsrfViewMiddleware',              # CSRF protection
    'django.contrib.auth.middleware.AuthenticationMiddleware',# Handles authentication
    'django.contrib.messages.middleware.MessageMiddleware',   # Handles flash messages
    'django.middleware.clickjacking.XFrameOptionsMiddleware', # Prevent clickjacking
]

# URL configuration
ROOT_URLCONF = 'mini_shop.urls'
# Root URL configuration module for the project

# Templates
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        # Use Django's template engine
        'DIRS': [BASE_DIR / 'templates'],  # Global templates folder
        'APP_DIRS': True,  # Enable templates inside app folders
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',   # Debug info
                'django.template.context_processors.request', # Request object in templates
                'django.contrib.auth.context_processors.auth',# User object in templates
                'django.contrib.messages.context_processors.messages', # Messages in templates
                'apps.cart.context_processors.cart_context',  # Custom cart info globally
            ],
        },
    },
]

# WSGI
WSGI_APPLICATION = 'mini_shop.wsgi.application'
# WSGI entry point for deployment (web servers use this to serve your app)

# Database
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',  # SQLite database engine
        'NAME': BASE_DIR / 'db.sqlite3',        # Database file location
    }
}

# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]
# Ensures strong passwords for users

# Localization
LANGUAGE_CODE = 'en-us'
# Default language

TIME_ZONE = 'UTC'
# Default timezone

USE_I18N = True
# Enable Django's internationalization system

USE_TZ = True
# Enable timezone-aware datetimes

# Static files
STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']  
# URL path and folder for static files (CSS, JS, images)

# Media files
MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'
# URL path and folder for uploaded media files

# Default primary key field type
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
# Default auto-incrementing primary key for models

# Custom user model
AUTH_USER_MODEL = 'accounts.CustomUser'
# Use a custom user model instead of default Django User

# Authentication redirects
LOGIN_URL = '/accounts/login/'            # Where users are redirected for login
LOGIN_REDIRECT_URL = '/'                  # Where users go after logging in
LOGOUT_REDIRECT_URL = '/accounts/login/' # Where users go after logging out

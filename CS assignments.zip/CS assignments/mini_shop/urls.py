from django.contrib import admin
# Imports Django's built-in admin site functionality

from django.urls import path, include
# Imports functions to define URL patterns and include other URL configs

from apps.home import views  # import home app views
# Imports the views module from the 'home' app to reference view functions directly

urlpatterns = [
    path('admin/', admin.site.urls),
    # URL for Django admin interface (e.g., /admin/)

    # Accounts
    path('accounts/', include(('apps.accounts.urls', 'accounts'), namespace='accounts')),
    # Includes URL patterns from the accounts app under /accounts/
    # 'namespace' allows reversing URLs uniquely for this app

    # Other apps
    path('cart/', include(('apps.cart.urls', 'cart'), namespace='cart')),
    # Includes URL patterns from cart app under /cart/

    path('dashboard/', include(('apps.dashboard.urls', 'dashboard'), namespace='dashboard')),
    # Includes URL patterns from dashboard app under /dashboard/

    path('home/', include(('apps.home.urls', 'home'), namespace='home')),
    # Includes URL patterns from home app under /home/

    path('orders/', include(('apps.orders.urls', 'orders'), namespace='orders')),
    # Includes URL patterns from orders app under /orders/

    path('products/', include(('apps.products.urls', 'products'), namespace='products')),
    # Includes URL patterns from products app under /products/

    # Root URL → home index view
    path('', views.index, name='home-index'),
    # The base URL ('/') is routed to the home app's index view
]

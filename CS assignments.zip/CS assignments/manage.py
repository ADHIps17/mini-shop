import os
# Imports the 'os' module to interact with the operating system (e.g., environment variables, paths)

import sys
# Imports the 'sys' module to access system-specific parameters and functions (like sys.argv for command-line arguments)

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
# Adds the current directory (where manage.py is located) to Python's module search path.
# This ensures that Django can properly find and import project modules.

def main():
    """Run administrative tasks."""
    # This function is the entry point of the script, used to run Django commands like runserver, migrate, etc.

    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mini_shop.settings')
    # Sets the environment variable 'DJANGO_SETTINGS_MODULE' to point to the project's settings file.
    # If it's already set, it will NOT overwrite it.

    try:
        from django.core.management import execute_from_command_line
        # Imports Django's function that processes command-line arguments (e.g., python manage.py runserver)
    except ImportError as exc:
        # If Django isn't installed, this block runs
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
        # Raises a helpful error message if Django could not be imported

    execute_from_command_line(sys.argv)
    # Passes all command-line arguments (like runserver, makemigrations, migrate) to Django for execution

if __name__ == '__main__':
    # This condition checks if the script is being run directly (not imported as a module)
    main()
    # Calls the main() function to start Django’s management tasks
